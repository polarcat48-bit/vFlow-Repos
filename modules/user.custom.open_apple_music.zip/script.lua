-- 使用 monkey 类别启动，系统会自动寻找主入口，无需指定具体 Activity 类名
local am_command = "monkey -p com.apple.android.music -c android.intent.category.LAUNCHER 1"

local success = vflow.shizuku.shell_command({
    command = am_command
})

return {
    result = success or "已发送启动指令"
}