-- 获取输入参数 "state" (对应 manifest 中的 inputs id)
local target_state = inputs.state

-- 定义要执行的命令变量
local cmd = ""
local msg = ""

-- 根据用户选择构建命令
if target_state == "开启" then
    cmd = "svc nfc enable"
    msg = "正在开启 NFC..."
else
    cmd = "svc nfc disable"
    msg = "正在关闭 NFC..."
end

-- 提示用户当前操作 (可选，增强体验)
vflow.device.toast({ message = msg })

-- 执行 Shell 命令
-- 注意：这里使用 "Root" 模式，因为 svc 命令通常需要 su 权限
local result = vflow.shizuku.shell_command({
    command = cmd,
    mode = "Root" 
})

-- 打印日志方便调试
print("执行命令: " .. cmd)
print("执行结果: " .. tostring(result))

-- 返回结果给后续步骤
-- 通常 shell_command 返回的是命令的标准输出
return {
    shell_output = tostring(result),
    success = true
}