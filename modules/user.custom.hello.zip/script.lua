local msg = inputs.msg
vflow.device.toast({ message = msg })